# OPENORCHID
A useful, ever expanding collection of GoPhish templates for when you need them most. 

# Installation & Usage
Simply select the guise preferred for your situation, and import the HTML code. 

Take a look at some of the favorites!

# Chipotle Promotion 
![alt text](https://github.com/nins3i/OPENORCHID/blob/master/chipotle.png)


# Microsoft Outlook Quarantined Email
![alt text](https://github.com/nins3i/OPENORCHID/blob/master/quarantine.png)

# Starbucks Elite Promotion
![alt text](https://github.com/nins3i/OPENORCHID/blob/master/starbucks.png)

# Suspicious Ebay Account Activity
![alt text](https://github.com/nins3i/OPENORCHID/blob/master/ebay.png)
