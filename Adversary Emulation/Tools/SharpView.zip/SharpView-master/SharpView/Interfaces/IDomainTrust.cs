﻿namespace SharpView.Interfaces
{
    public interface IDomainTrust
    {
        string SourceName { get; set; }
        string TargetName { get; set; }
    }
}
