﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpView.Enums
{
    public enum Version
    {
        All,
        V1,
        V2
    }
}
